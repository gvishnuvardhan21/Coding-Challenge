package com.java.crime.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.crime.model.Crime;

public interface CrimeDao {
 
	List<Crime> ShowCrimeDao() throws ClassNotFoundException, SQLException;
	Crime SearchByCrimeId(int crimeid) throws ClassNotFoundException, SQLException;
	List<Crime> SearchByIncidentType(String incidenttype) throws ClassNotFoundException, SQLException;
	List<Crime> SearchByIncidentDate(String incidentdate) throws ClassNotFoundException, SQLException;
	List<Crime> ShowAllOpenInci(String status) throws ClassNotFoundException, SQLException;
	String AddCrime(Crime crime) throws ClassNotFoundException, SQLException;
}

