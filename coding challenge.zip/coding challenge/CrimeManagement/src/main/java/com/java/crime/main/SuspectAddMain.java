package com.java.crime.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.crime.dao.SuspectDao;
import com.java.crime.dao.SuspectDaoImpl;
import com.java.crime.model.Suspect;

public class SuspectAddMain {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sr = new Scanner(System.in);
		SuspectDao dao = new SuspectDaoImpl();
		Suspect suspect = new Suspect();
		
		System.out.println("suspect id :");
		suspect.setSuspectid(sr.nextInt());
		System.out.println("crime id :");
		suspect.setCrimeid(sr.nextInt());
		System.out.println("name :");
		suspect.setName(sr.next());
		System.out.println("age :");
		suspect.setAge(sr.nextInt());
		System.out.println("description :");
		suspect.setDescription(sr.next());
		System.out.println("CriminalHistory: ");
		suspect.setCriminalHistory(sr.next());
		
		System.out.println(dao.AddSuspect(suspect));
	}
}
