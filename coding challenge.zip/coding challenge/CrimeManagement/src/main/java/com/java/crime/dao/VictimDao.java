package com.java.crime.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.crime.model.Crime;
import com.java.crime.model.Victim;

	public interface VictimDao {
		List<Victim> ShowVictimByCrimeid(int crimeid) throws ClassNotFoundException, SQLException;
		List<Victim> ShowVictimByVictimId(int victimid) throws ClassNotFoundException, SQLException;
		String AddVictim(Victim victim) throws ClassNotFoundException, SQLException;

	}


	