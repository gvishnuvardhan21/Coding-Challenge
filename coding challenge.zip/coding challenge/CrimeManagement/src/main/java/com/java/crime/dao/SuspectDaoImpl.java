package com.java.crime.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.crime.model.Suspect;
import com.java.crime.util.DBConnUtil;
import com.java.crime.util.DBPropertyUtil;
import com.mysql.cj.protocol.Resultset;

public class SuspectDaoImpl implements SuspectDao {
 
	Connection connection;
	PreparedStatement pst;
	@Override
	public String AddSuspect(Suspect suspect) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "insert into suspect(SuspectID,CrimeID,Name,age,Description,CriminalHistory) values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, suspect.getSuspectid());
		pst.setInt(2, suspect.getCrimeid());
		pst.setString(3, suspect.getName());
		pst.setInt(4, suspect.getAge());
		pst.setString(5, suspect.getDescription());
		pst.setString(6, suspect.getCriminalHistory());
		pst.executeUpdate();
		return "suspect added !!1";
	}
	@Override
	public List<Suspect> ShowSuspectsBySuspectId(int suspectid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "select * from suspect where suspectid = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, suspectid);
		ResultSet rs = pst.executeQuery();
		List<Suspect> SupectList = new ArrayList<Suspect>();
		
		Suspect suspect= null;
		while(rs.next())
		{
			suspect = new Suspect();
			suspect.setSuspectid(rs.getInt("suspectid"));
			suspect.setCrimeid(rs.getInt("crimeid"));
			suspect.setName(rs.getString("name"));
			suspect.setAge(rs.getInt("age"));
			suspect.setDescription(rs.getString("Description"));
			suspect.setCriminalHistory(rs.getString("CriminalHistory"));
			SupectList.add(suspect);
		}
		return SupectList;
	}
	@Override
	public List<Suspect> ShowSuspectsByCrimeId(int crimeid) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "select * from suspect where crimeid = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, crimeid);
		ResultSet rs = pst.executeQuery();
		List<Suspect> SupectList = new ArrayList<Suspect>();
		
		Suspect suspect= null;
		while(rs.next())
		{
			suspect = new Suspect();
			suspect.setSuspectid(rs.getInt("suspectid"));
			suspect.setCrimeid(rs.getInt("crimeid"));
			suspect.setName(rs.getString("name"));
			suspect.setAge(rs.getInt("age"));
			suspect.setDescription(rs.getString("Description"));
			suspect.setCriminalHistory(rs.getString("CriminalHistory"));
			SupectList.add(suspect);
		}
		return SupectList;
	}

}
