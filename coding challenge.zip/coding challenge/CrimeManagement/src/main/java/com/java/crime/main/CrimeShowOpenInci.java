package com.java.crime.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.crime.dao.CrimeDao;
import com.java.crime.dao.CrimeDaoImpl;
import com.java.crime.model.Crime;

public class CrimeShowOpenInci {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Scanner sr = new Scanner(System.in);
		System.out.println("enter thr status to search :");
		String status = sr.next();
		
		CrimeDao dao = new CrimeDaoImpl();
		
		List<Crime> Crimestatus = dao.ShowAllOpenInci(status);
		for (Crime crime : Crimestatus) {
			System.out.println(crime);
		}
	}
}
