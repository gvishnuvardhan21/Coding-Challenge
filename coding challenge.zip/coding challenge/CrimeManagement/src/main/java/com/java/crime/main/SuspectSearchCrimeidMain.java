package com.java.crime.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.crime.dao.SuspectDao;
import com.java.crime.dao.SuspectDaoImpl;
import com.java.crime.model.Suspect;

public class SuspectSearchCrimeidMain {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		int crimeid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Crime ID : ");
		crimeid = sc.nextInt();
		SuspectDao dao = new SuspectDaoImpl();
	
			List<Suspect> SusByCrimeIDList = dao.ShowSuspectsByCrimeId(crimeid);
			
			for (Suspect suspect : SusByCrimeIDList) 
			{
				System.out.println(suspect);
			}
		
	}
}
