package com.java.crime.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.crime.dao.*;
import com.java.crime.model.Victim;

public class VictimAddMain {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Scanner sr = new Scanner(System.in);
		Victim victim = new Victim();
		
		System.out.println("enter victim id:");
		victim.setCrimeid(sr.nextInt());
		System.out.println("enter crimeid :");
		victim.setCrimeid(sr.nextInt());
		System.out.println("enter name :");
		victim.setName(sr.next());
		System.out.println("enter age: ");
		victim.setAge(sr.nextInt());
		System.out.println("enter contact info :");
		victim.setContactInfo(sr.next());
		System.out.println("inter injuries :");
		victim.setInjuries(sr.next());
		
		VictimDao dao = new VictimDaoImpl();
		System.out.println(dao.AddVictim(victim));
	}
}
