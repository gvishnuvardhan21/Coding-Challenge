package com.java.crime.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.crime.model.Crime;
import com.java.crime.util.DBConnUtil;
import com.java.crime.util.DBPropertyUtil;


public class CrimeDaoImpl implements CrimeDao {
	Connection connection;
	PreparedStatement pst;

	@Override
	public List<Crime> ShowCrimeDao() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from crime";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Crime> crimeList = new ArrayList<Crime>();
		Crime crime = null;
		while(rs.next())
		{
			crime = new Crime();
			crime.setCrimeid(rs.getInt("crimeid"));
			crime.setIncidenttype(rs.getString("incidenttype"));
			crime.setIncidentdate(rs.getString("incidentdate"));
			crime.setLocation(rs.getString("location"));
			crime.setDesc(rs.getString("description"));
			crime.setStatus(rs.getString("status"));
			crimeList.add(crime);
		}
		return crimeList;
		
	}

	@Override
	public Crime SearchByCrimeId(int crimeid) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from crime where crimeid=?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, crimeid);
		ResultSet rs = pst.executeQuery();
		Crime crime = null;
		if(rs.next())
		{
			crime = new Crime();
			crime.setCrimeid(rs.getInt("crimeid"));
			crime.setIncidenttype(rs.getString("incidenttype"));
			crime.setIncidentdate(rs.getString("incidentdate"));
			crime.setLocation(rs.getString("location"));
			crime.setDesc(rs.getString("description"));
			crime.setStatus(rs.getString("status"));
		}
		return crime;
	}

	@Override
	public List<Crime> SearchByIncidentType(String incidenttype) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from crime where IncidentType= ?";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, incidenttype);
		ResultSet rs = pst.executeQuery();
		List<Crime> crimeList = new ArrayList<Crime>();
		Crime crime = null;
		while(rs.next())
		{
			crime = new Crime();
			crime.setCrimeid(rs.getInt("crimeid"));
			crime.setIncidenttype(rs.getString("incidenttype"));
			crime.setIncidentdate(rs.getString("incidentdate"));
			crime.setLocation(rs.getString("location"));
			crime.setDesc(rs.getString("description"));
			crime.setStatus(rs.getString("status"));
			crimeList.add(crime);
		}
		return crimeList;
	}

	@Override
	public List<Crime> SearchByIncidentDate(String incidentdate) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from crime where Incidentdate= ?";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, incidentdate);
		ResultSet rs = pst.executeQuery();
		List<Crime> crimeList = new ArrayList<Crime>();
		Crime crime = null;
		while(rs.next())
		{
			crime = new Crime();
			crime.setCrimeid(rs.getInt("crimeid"));
			crime.setIncidenttype(rs.getString("incidenttype"));
			crime.setIncidentdate(rs.getString("incidentdate"));
			crime.setLocation(rs.getString("location"));
			crime.setDesc(rs.getString("description"));
			crime.setStatus(rs.getString("status"));
			crimeList.add(crime);
		}
		return crimeList;
	}

	@Override
	public List<Crime> ShowAllOpenInci(String status) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from crime where status= ?";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, status);
		ResultSet rs = pst.executeQuery();
		List<Crime> crimeList = new ArrayList<Crime>();
		Crime crime = null;
		while(rs.next())
		{
			crime = new Crime();
			crime.setCrimeid(rs.getInt("crimeid"));
			crime.setIncidenttype(rs.getString("incidenttype"));
			crime.setIncidentdate(rs.getString("incidentdate"));
			crime.setLocation(rs.getString("location"));
			crime.setDesc(rs.getString("description"));
			crime.setStatus(rs.getString("status"));
			crimeList.add(crime);
		}
		return crimeList;
	}

	@Override
	public String AddCrime(Crime crime) throws ClassNotFoundException, SQLException {
		String ConnStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(ConnStr);
		String cmd = "Insert into crime(CrimeID,IncidentType,IncidentDate,Location,Description,Status)"+ "values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, crime.getCrimeid());
		pst.setString(2, crime.getIncidenttype());
		pst.setString(3, crime.getIncidentdate());
		pst.setString(4, crime.getLocation());
		pst.setString(5, crime.getDesc());
		pst.setString(6, crime.getStatus());
		pst.executeUpdate();
		return "Crime is Added!!!";
		
	}

}
