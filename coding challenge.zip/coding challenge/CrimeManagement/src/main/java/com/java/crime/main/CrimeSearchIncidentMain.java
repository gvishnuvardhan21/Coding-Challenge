package com.java.crime.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.crime.dao.CrimeDao;
import com.java.crime.dao.CrimeDaoImpl;
import com.java.crime.model.Crime;

public class CrimeSearchIncidentMain {
	public static void main(String[] args) {
		Scanner sr = new Scanner(System.in);
		CrimeDao dao = new CrimeDaoImpl();
		
		System.out.println("enter thr incident type to search :");
		String incidenttype = sr.next();
		List<Crime> crimeList = null;
		try {
			crimeList = dao.SearchByIncidentType(incidenttype);
			for (Crime crime : crimeList) {
				System.out.println(crime);}
			}
		 catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
