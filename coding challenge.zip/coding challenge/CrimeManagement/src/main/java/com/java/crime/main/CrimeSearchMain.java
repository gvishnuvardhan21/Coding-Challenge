package com.java.crime.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.crime.dao.CrimeDao;
import com.java.crime.dao.CrimeDaoImpl;
import com.java.crime.model.Crime;

public class CrimeSearchMain {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sr = new Scanner(System.in);
		CrimeDao dao = new CrimeDaoImpl();
		
		System.out.println("enter thr crime id to search :");
		int crimeid = sr.nextInt();
		Crime crime = dao.SearchByCrimeId(crimeid);
		if(crime != null)
		{
			System.out.println(crime);
		}
		else
			System.out.println("data not found !! ");
		
	}
}
