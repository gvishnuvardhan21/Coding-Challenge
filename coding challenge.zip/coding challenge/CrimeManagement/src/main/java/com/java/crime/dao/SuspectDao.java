package com.java.crime.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.crime.model.Suspect;

public interface SuspectDao 
{
	String AddSuspect(Suspect suspect) throws ClassNotFoundException, SQLException;
	List<Suspect> ShowSuspectsBySuspectId(int suspectid) throws ClassNotFoundException, SQLException;
	List<Suspect> ShowSuspectsByCrimeId(int crimeid) throws ClassNotFoundException, SQLException;
	
}
