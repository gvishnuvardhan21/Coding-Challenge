package com.java.crime.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.java.crime.dao.CrimeDao;
import com.java.crime.dao.CrimeDaoImpl;
import com.java.crime.model.Crime;

public class CrimeSearchIncidentDateMain {
	public static void main(String[] args) throws ParseException {
		String IncDate;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Date (yyyy-mm-dd) : ");
		IncDate = sc.next();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = sdf.parse(IncDate);
		
		CrimeDao dao = new CrimeDaoImpl();
		List<Crime> crimedate;
		try {
			crimedate = dao.SearchByIncidentDate(IncDate);
			for (Crime crime : crimedate) {
				System.out.println(crime);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
