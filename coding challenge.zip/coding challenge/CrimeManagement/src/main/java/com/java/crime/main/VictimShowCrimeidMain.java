package com.java.crime.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.crime.dao.*;
import com.java.crime.model.Victim;

public class VictimShowCrimeidMain {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		int crimeid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Crime id : ");
		crimeid = sc.nextInt();
		VictimDao dao = new VictimDaoImpl();

			List<Victim> VictimList = dao.ShowVictimByCrimeid(crimeid);
			for (Victim victim : VictimList) {
				System.out.println(victim);
			}
}
}
