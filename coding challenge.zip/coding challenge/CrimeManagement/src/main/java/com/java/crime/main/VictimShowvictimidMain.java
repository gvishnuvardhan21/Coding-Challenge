package com.java.crime.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.crime.dao.VictimDao;
import com.java.crime.dao.VictimDaoImpl;
import com.java.crime.model.Victim;

public class VictimShowvictimidMain {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		int victimid;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Crime id : ");
		victimid = sc.nextInt();
		VictimDao dao = new VictimDaoImpl();

			List<Victim> VictimList = dao.ShowVictimByVictimId(victimid);
			for (Victim victim : VictimList) {
				System.out.println(victim);
			}
}
}
