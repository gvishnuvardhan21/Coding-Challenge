package com.java.crime.model;

public class Suspect {
	private int suspectid;
	private int crimeid;
	private String name;
	private int age;
	private String description;
	private String criminalHistory;
	public int getSuspectid() {
		return suspectid;
	}
	public void setSuspectid(int suspectid) {
		this.suspectid = suspectid;
	}
	public int getCrimeid() {
		return crimeid;
	}
	public void setCrimeid(int crimeid) {
		this.crimeid = crimeid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCriminalHistory() {
		return criminalHistory;
	}
	public void setCriminalHistory(String criminalHistory) {
		this.criminalHistory = criminalHistory;
	}
	public Suspect(int suspectid, int crimeid, String name, int age, String description, String criminalHistory) {
		this.suspectid = suspectid;
		this.crimeid = crimeid;
		this.name = name;
		this.age = age;
		this.description = description;
		this.criminalHistory = criminalHistory;
	}
	public Suspect() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Suspect [suspectid=" + suspectid + ", crimeid=" + crimeid + ", name=" + name + ", age=" + age
				+ ", description=" + description + ", criminalHistory=" + criminalHistory + "]";
	}

}
