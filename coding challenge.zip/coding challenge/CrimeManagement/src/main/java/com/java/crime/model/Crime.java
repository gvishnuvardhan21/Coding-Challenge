package com.java.crime.model;

import java.util.Date;

public class Crime {
	
	private int crimeid;
	private String incidenttype;
	private String incidentdate;
	private String location;
	private String desc;
	private String status;
	public int getCrimeid() {
		return crimeid;
	}
	public void setCrimeid(int crimeid) {
		this.crimeid = crimeid;
	}
	public String getIncidenttype() {
		return incidenttype;
	}
	public void setIncidenttype(String incidenttype) {
		this.incidenttype = incidenttype;
	}
	public String getIncidentdate() {
		return incidentdate;
	}
	public void setIncidentdate(String date) {
		this.incidentdate = date;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Crime(int crimeid, String incidenttype, String incidentdate, String location, String desc, String status) {
		this.crimeid = crimeid;
		this.incidenttype = incidenttype;
		this.incidentdate = incidentdate;
		this.location = location;
		this.desc = desc;
		this.status = status;
	}
	public Crime() {
	}
	@Override
	public String toString() {
		return "Crime [crimeid=" + crimeid + ", incidenttype=" + incidenttype + ", incidentdate=" + incidentdate
				+ ", location=" + location + ", desc=" + desc + ", status=" + status + "]";
	}
	
}
